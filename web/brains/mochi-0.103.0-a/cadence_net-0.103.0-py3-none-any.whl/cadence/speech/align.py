"""Training from transcripts: a lesson for every step from the brain's own beliefs.

A transcript says which symbols an utterance holds and not when. The lesson gives each step a
target by the best monotonic path of the transcript through the brain's own per-step beliefs
(``forced_path``, the forced alignment of CTC: blank may fill any step and parts a doubled
letter). The path is computed outside the brain, by the teacher, and taught as labels; the brain
learns by its own rule. Before a brain believes anything, ``even_path`` spreads the symbols
evenly.

``soft_path`` gives each step a distribution in place of one symbol: the share of the
transcript's paths that say each symbol at that step, every path weighed by the brain's beliefs
along it (the occupation shares of CTC's forward and backward sums). Taught as a lesson's
``targets``, the pull on the motor neurons at every step is the descent direction of CTC's loss
on the brain's beliefs, computed, as the path is, outside the brain from its beliefs alone.
``soft_step`` is one moment of that lesson: the pull, then a greedy act.

``Alignments`` holds the paths of utterances to come, one per hearing: an utterance heard in two
passes takes a path in each, and using one never removes the other. ``log_beliefs`` reads a
frozen copy's beliefs for several utterances heard side by side.
"""

from __future__ import annotations

from collections.abc import Hashable, Sequence
from typing import Any

import numpy as np

from .decode import BLANK


def _symbols(transcript: Any) -> np.ndarray:
    """A transcript as its symbols: a sequence of whole numbers from zero. A fraction is refused,
    where a conversion would round it to another symbol."""
    given = np.asarray(transcript)
    if given.ndim != 1 or (len(given) and (
        given.dtype.kind not in "iuf"
        or not np.isfinite(given).all()
        or (given != np.floor(given)).any()
        or (given < 0).any()
        or int(given.max()) >= 2**63
    )):
        raise ValueError("a transcript is a sequence of symbols, each a whole number from zero")
    return given.astype(np.int64)


def _beliefs(name: str, log_beliefs: Any, transcript: Any, blank: Any
             ) -> tuple[np.ndarray, np.ndarray]:
    """What ``forced_path`` and ``soft_path`` lay a path through: ``(steps, symbols)`` beliefs
    and a transcript of one symbol or more, each one of the beliefs' symbols. The blank is one
    of them too, and no symbol of the transcript: a path says it between symbols, and its
    reading (``collapse``) holds none."""
    scores = np.asarray(log_beliefs, dtype=np.float64)
    sequence = _symbols(transcript)
    if scores.ndim != 2 or len(sequence) == 0:
        raise ValueError(f"{name} needs (steps, symbols) beliefs and a symbol")
    symbols = scores.shape[1]
    if (
        isinstance(blank, (bool, np.bool_))
        or not isinstance(blank, (int, np.integer))
        or not 0 <= blank < symbols
    ):
        raise ValueError(f"blank must be one of the beliefs' {symbols} symbols")
    if (sequence >= symbols).any():
        raise ValueError(f"the transcript holds a symbol outside the beliefs' {symbols} symbols")
    if (sequence == blank).any():
        raise ValueError("the transcript holds the blank, which is no symbol of a transcript")
    return scores, sequence


def even_path(steps: int, transcript: Any) -> np.ndarray:
    """Each step's symbol on an even split of ``steps`` among the transcript's symbols, which
    are whole numbers from zero."""
    symbols = _symbols(transcript)
    if steps < 1 or len(symbols) == 0:
        raise ValueError("even_path needs a step and a symbol")
    n = len(symbols)
    return symbols[np.minimum((np.arange(steps) * n) // steps, n - 1)]


def forced_path(log_beliefs: Any, transcript: Any, *, blank: int = BLANK,
                states: bool = False) -> np.ndarray:
    """The symbol taught at each step: the transcript's best monotonic path through
    ``(steps, symbols)`` log beliefs, blank allowed on any step and required between a symbol
    and the same symbol after it (CTC's forced alignment, by Viterbi). With ``states`` the
    path's state at each step instead: ``2k + 1`` on the transcript's k-th symbol, even on a
    blank. The path's symbols read as the transcript (``collapse``). A belief may be zero (a
    log belief of ``-inf``) on steps the path does not take.

    Refused: a transcript longer than the steps allow; a transcript the beliefs leave no path,
    every one of its paths passing a step of belief zero; symbols that are not whole numbers
    among the beliefs' symbols, or that hold the blank; a blank that is not one of the beliefs'
    symbols; beliefs with NaN or positive infinity."""
    scores, sequence = _beliefs("forced_path", log_beliefs, transcript, blank)
    repeats = int(np.sum(sequence[1:] == sequence[:-1]))
    if len(scores) < len(sequence) + repeats:
        raise ValueError("the transcript needs more steps than the utterance holds")
    if np.isnan(scores).any() or np.isposinf(scores).any():
        raise ValueError("forced_path needs beliefs without NaN or positive infinity")
    frames = len(scores)
    labels = np.full(2 * len(sequence) + 1, blank, dtype=np.int64)
    labels[1::2] = sequence
    n = len(labels)
    skip = np.zeros(n, dtype=bool)  # a symbol reachable from two states back
    skip[3::2] = labels[3::2] != labels[1:-2:2]
    best = np.full((frames, n), -np.inf)
    back = np.zeros((frames, n), dtype=np.int64)
    best[0, 0] = scores[0, labels[0]]
    best[0, 1] = scores[0, labels[1]]
    for t in range(1, frames):
        stay = best[t - 1]
        one = np.concatenate([[-np.inf], best[t - 1, :-1]])
        two = np.where(skip, np.concatenate([[-np.inf, -np.inf], best[t - 1, :-2]]), -np.inf)
        choice = np.argmax(np.stack([stay, one, two]), axis=0)
        best[t] = np.choose(choice, [stay, one, two]) + scores[t, labels]
        back[t] = choice
    k = n - 1 if best[-1, n - 1] >= best[-1, n - 2] else n - 2
    if not best[-1, k] > -np.inf:
        # neither end state is reached: tracing back from one would give a path that begins
        # past the transcript's first symbols
        raise ValueError("the beliefs leave the transcript no path")
    path = np.zeros(frames, dtype=np.int64)
    for t in range(frames - 1, -1, -1):
        path[t] = k if states else labels[k]
        k -= int(back[t, k])
    return path


def soft_path(log_beliefs: Any, transcript: Any, *, blank: int = BLANK,
              sharpness: float = 1.0) -> np.ndarray:
    """The distribution taught at each step: ``(steps, symbols)``, the share of the transcript's
    monotonic paths that say each symbol at that step, each path weighed by the product of the
    beliefs along it. The paths are ``forced_path``'s: blank allowed on any step and required
    between a symbol and the same symbol after it. Every row sums to one. Where the beliefs
    leave one path, the rows are that path's symbols; where they say nothing, the rows spread
    each symbol over the steps it can take. ``sharpness`` raises every path's weight to that
    power: at 1 a path counts by its probability (CTC's shares), above 1 the better paths count
    for more, and at a large value the rows are the forced path's symbols. A transcript longer
    than the steps allow is refused, and the transcript's symbols and the blank are taken and
    refused as ``forced_path`` takes them."""
    if (
        isinstance(sharpness, (bool, np.bool_))
        or not isinstance(sharpness, (int, float, np.integer, np.floating))
        or not np.isfinite(sharpness)
        or sharpness <= 0
    ):
        raise ValueError("sharpness must be a positive finite number")
    scores, sequence = _beliefs("soft_path", log_beliefs, transcript, blank)
    if sharpness != 1.0:
        scores = scores * float(sharpness)
    repeats = int(np.sum(sequence[1:] == sequence[:-1]))
    if len(scores) < len(sequence) + repeats:
        raise ValueError("the transcript needs more steps than the utterance holds")
    if np.isnan(scores).any():
        raise ValueError("soft_path needs beliefs without NaN")
    frames = len(scores)
    labels = np.full(2 * len(sequence) + 1, blank, dtype=np.int64)
    labels[1::2] = sequence
    n = len(labels)
    skip = np.zeros(n, dtype=bool)  # a symbol reachable from two states back
    skip[3::2] = labels[3::2] != labels[1:-2:2]
    emit = scores[:, labels]  # (steps, states)
    none = np.full(2, -np.inf)
    with np.errstate(invalid="ignore"):  # sums of impossible states stay impossible
        ahead = np.full((frames, n), -np.inf)  # every path to a state, its step's belief included
        ahead[0, :2] = emit[0, :2]
        for t in range(1, frames):
            stay = ahead[t - 1]
            one = np.concatenate([none[:1], stay[:-1]])
            two = np.where(skip, np.concatenate([none, stay[:-2]]), -np.inf)
            ahead[t] = np.logaddexp(np.logaddexp(stay, one), two) + emit[t]
        after = np.full((frames, n), -np.inf)  # every path from a state on, its step's excluded
        after[-1, -2:] = 0.0
        for t in range(frames - 2, -1, -1):
            onward = after[t + 1] + emit[t + 1]
            one = np.concatenate([onward[1:], none[:1]])
            two = np.concatenate([np.where(skip[2:], onward[2:], -np.inf), none])
            after[t] = np.logaddexp(np.logaddexp(onward, one), two)
        total = np.logaddexp(ahead[-1, -1], ahead[-1, -2])
    if not np.isfinite(total):
        raise ValueError("the beliefs leave the transcript no path")
    with np.errstate(invalid="ignore"):
        shares = np.exp(ahead + after - total)
    shares = np.nan_to_num(shares, nan=0.0)
    out = np.zeros_like(scores)
    np.add.at(out, (np.arange(frames)[:, None], labels[None, :]), shares)
    return np.asarray(out / out.sum(axis=1, keepdims=True))


def soft_step(brain: Any, rows: Any, targets: Any) -> dict[str, float]:
    """One moment of a soft lesson, in place of ``brain.step(rows, teacher=labels)``: the lesson
    pulls each stream toward its row of ``targets`` (``Brain.lesson(targets=...)``), then the
    brain answers the moment greedily, which carries its streams on. Learned fields take their
    one step of the moment at the act, as in ``step``, and are held during the lesson. Returns
    the lesson's report."""
    fields = getattr(brain, "fields", None)
    moving = fields if fields is not None and fields.learning else None
    if moving is not None:
        moving.learning = False
    try:
        report: dict[str, float] = brain.lesson(rows, targets=targets)
    finally:
        if moving is not None:
            moving.learning = True
    brain.act(rows, greedy=True)
    return report


def log_beliefs(brain: Any, utterances: Sequence[Any], *, hold: bool = False) -> list[np.ndarray]:
    """A brain's log beliefs over its symbols at each step of each utterance, the utterances
    heard side by side as streams from rest and answered greedily: the log-softmax of the settled
    motor activations at the brain's temperature. The brain's streams start again; give it a
    frozen copy (``Brain.load`` of a saved brain) where the life must go on untouched.

    With ``hold`` the brain's learned fields take no step while it answers, and its streams are
    at rest again afterwards, so between two batches of its life a brain of learned fields (the
    recipe's brain) reads its own beliefs and no copy is loaded: its parameters are what they
    were. Its acts are acts: a learned code takes its step at each one, and a brain with
    ``surprise`` learns its usual residuals; read such a brain from a copy."""
    rows = [np.asarray(u, dtype=np.float64) for u in utterances]
    if not rows:
        return []
    longest = max(len(r) for r in rows)
    x = np.stack([np.concatenate([r, np.repeat(r[-1:], longest - len(r), axis=0)])
                  for r in rows], axis=1)
    fields = getattr(brain, "fields", None)
    moving = fields if hold and fields is not None and fields.learning else None
    if moving is not None:
        moving.learning = False
    try:
        brain.reset()
        motor = np.asarray(brain.connectome.populations["motor"], dtype=np.int64)
        temperature = float(brain.describe()["genes"]["temperature"])
        out = np.zeros((longest, len(rows), len(motor)))
        for t in range(longest):
            brain.act(x[t], greedy=True)
            drive = np.asarray(brain.basal_ganglia.state.activation)[:, motor] / temperature
            top = drive.max(axis=1, keepdims=True)
            out[t] = drive - top - np.log(np.sum(np.exp(drive - top), axis=1, keepdims=True))
        if hold:
            brain.reset()
    finally:
        if moving is not None:
            moving.learning = True
    return [out[: len(r), k] for k, r in enumerate(rows)]


class Alignments:
    """The paths of hearings to come, one per hearing.

    ``key`` names a hearing (a pass and a place in it, for instance), not an utterance, so an
    utterance heard twice holds two paths and taking one leaves the other. ``even`` sets a
    hearing's path before any beliefs, ``realign`` from a frozen copy's log beliefs (``soft``:
    the soft path, a distribution per step), ``take`` returns it and forgets it. ``lesson``
    gives the labels of hearings heard side by side and ``targets`` their distributions.
    """

    def __init__(self, *, blank: int = BLANK) -> None:
        if (isinstance(blank, (bool, np.bool_)) or not isinstance(blank, (int, np.integer))
                or blank < 0):
            raise ValueError("blank must be a nonnegative integer symbol")
        self.blank = int(blank)
        self._paths: dict[Hashable, np.ndarray] = {}

    def __len__(self) -> int:
        return len(self._paths)

    def __contains__(self, key: Hashable) -> bool:
        return key in self._paths

    def even(self, key: Hashable, steps: int, transcript: Any) -> np.ndarray:
        self._paths[key] = even_path(steps, transcript)
        return self._paths[key]

    def realign(self, key: Hashable, log_beliefs: Any, transcript: Any, *,
                soft: bool = False, sharpness: float = 1.0) -> np.ndarray:
        """Hold the hearing's path through ``log_beliefs``: the best path's symbols
        (``forced_path``), or with ``soft`` the soft path's distributions (``soft_path`` at
        ``sharpness``)."""
        if soft:
            self._paths[key] = soft_path(log_beliefs, transcript, blank=self.blank,
                                         sharpness=sharpness)
        else:
            self._paths[key] = forced_path(log_beliefs, transcript, blank=self.blank)
        return self._paths[key]

    def take(self, key: Hashable) -> np.ndarray:
        if key not in self._paths:
            raise KeyError(f"no path is held for the hearing {key!r}")
        return self._paths.pop(key)

    def lesson(self, keys: Sequence[Hashable], steps: int) -> np.ndarray:
        """The labels of hearings heard side by side: ``(steps, len(keys))``, each column its
        hearing's path, then blank on the steps after its end. Taking them forgets them. A
        hearing that holds a soft path is refused: its lesson is ``targets``."""
        if len(set(keys)) != len(keys):
            raise ValueError("a hearing can be taken only once per lesson")
        for key in keys:
            if key not in self._paths:
                raise KeyError(f"no path is held for the hearing {key!r}")
            if self._paths[key].ndim != 1:
                raise ValueError(
                    f"the hearing {key!r} holds a soft path: teach it with targets()"
                )
        out = np.full((steps, len(keys)), self.blank, dtype=np.int64)
        for k, key in enumerate(keys):
            path = self._paths[key]
            if len(path) > steps:
                raise ValueError("a hearing's path is longer than the steps of its lesson")
            out[: len(path), k] = path
        for key in keys:
            del self._paths[key]
        return out

    def targets(self, keys: Sequence[Hashable], steps: int, symbols: int) -> np.ndarray:
        """The distributions of hearings heard side by side: ``(steps, len(keys), symbols)``,
        row ``[t, k]`` what ``Brain.lesson(targets=...)`` teaches stream ``k`` at step ``t``. A
        hearing's soft path is given as held, a path of symbols as one-hot rows, and the steps
        after a hearing's end are blank. Taking them forgets them."""
        if self.blank >= symbols:
            raise ValueError(f"blank must be one of the {symbols} symbols")
        if len(set(keys)) != len(keys):
            raise ValueError("a hearing can be taken only once per lesson")
        for key in keys:
            if key not in self._paths:
                raise KeyError(f"no path is held for the hearing {key!r}")
            held = self._paths[key]
            if len(held) > steps:
                raise ValueError("a hearing's path is longer than the steps of its lesson")
            if held.ndim == 2 and held.shape[1] != symbols:
                raise ValueError(
                    f"the hearing {key!r} holds distributions over {held.shape[1]} symbols, "
                    f"not {symbols}"
                )
            if held.ndim == 1 and len(held) and (held.min() < 0 or int(held.max()) >= symbols):
                raise ValueError(f"the hearing {key!r} holds a symbol outside the {symbols}")
        out = np.zeros((steps, len(keys), symbols))
        out[:, :, self.blank] = 1.0
        for k, key in enumerate(keys):
            path = self._paths[key]
            if path.ndim == 1:
                out[: len(path), k, self.blank] = 0.0
                out[np.arange(len(path)), k, path] = 1.0
            else:
                out[: len(path), k] = path
        for key in keys:
            del self._paths[key]
        return out
